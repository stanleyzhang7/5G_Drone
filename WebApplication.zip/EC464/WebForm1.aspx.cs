﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Threading.Tasks;
using System.Diagnostics;

namespace EC464
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        public void predict(object sender, EventArgs e)
        {

            double coef = -0.12593099;
            double inter = 56.88062314393973;

            double temp = Convert.ToDouble(inp_alt.Text); 
            double pred = (coef * temp) + inter;

            pred_data.Text = pred.ToString();
        }

        public void clear_field(object sender, EventArgs e)
        {
            pred_data.Text = "0";
            inp_alt.Text = "0";
        }
    }
}