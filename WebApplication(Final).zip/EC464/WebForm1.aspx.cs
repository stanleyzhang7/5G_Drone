﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Threading.Tasks;
using System.Diagnostics;


using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;
using Newtonsoft.Json;

namespace EC464
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        IFirebaseConfig config = new FirebaseConfig
        {
            AuthSecret = "2CtTwmFQeaBZ8WNAXgLokuXxLFLolXVSkYjykwLV",
            BasePath = "https://drone-34faa-default-rtdb.firebaseio.com/"
        };
        IFirebaseClient client;
        protected void Page_Load(object sender, EventArgs e)
        {
            client = new FireSharp.FirebaseClient(config);
            
        }

        public void predict(object sender, EventArgs e)
        {

            double coef = -0.12593099;
            double inter = 56.88062314393973;

            double temp = Convert.ToDouble(alt.Text); 
            double pred = (coef * temp) + inter;

            pred_data.Text = pred.ToString();
        }

        public void clear_field(object sender, EventArgs e)
        {
            pred_data.Text = "0";
            alt.Text = "0";
            longi.Text = "0";
            lat.Text = "0";
            ds.Text = "0";
            us.Text = "0";
        }

        public void retrieve(object sender, EventArgs e)
        {
            int i = 0;
            FirebaseResponse response;
            response = client.Get("user/");
            Data obj = response.ResultAs<Data>();
            var json = response.Body;
            //lat.Text = json.ToString();
            Dictionary<string, Data> elist = JsonConvert.DeserializeObject<Dictionary<string, Data>>(json);
            foreach (KeyValuePair<string, Data> el in elist)
            {
                if (i == 0)
                {
                    lat.Text = el.Value.endLatitude.ToString();
                    longi.Text = el.Value.endLongitude.ToString();
                    alt.Text = el.Value.altitude.ToString();
                    ds.Text = el.Value.downloadMbps.ToString();
                    us.Text = el.Value.uploadMbps.ToString();
                    i++;
                }
                
            }
            

        }
    }
}