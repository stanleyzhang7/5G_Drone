﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EC464
{
    internal class Data
    {
        public object altitude { get; set; }
        public object downloadMbps { get; set; }
        public object endLatitude { get; set; }
        public object endLongitude { get; set; }
        public object ipAddress{ get; set; }
        public object ispName { get; set; }
        public object jitter { get; set; }
        public object latency { get; set; }
        public object regionName { get; set; }
        public object serverName { get; set; }
        public object startLatitude { get; set; }
        public object startLongitude { get; set; }
        public object uploadMbps { get; set; }

    }
}